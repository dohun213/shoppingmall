//package com.example.shoppingmall.controller;
//
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class SampleController {
//
//    @GetMapping("/")
//    public String hello() {
//        return "쇼핑몰 홈페이지에 오신 걸 환영합니다!";
//    }
//}